public class Amazon implements CloudHostingProvider, CDNProvider, CloudStorageProvider {

    @Override
    public void createServer(String region) {
        System.out.println("Amazon: Server created in region " + region);
    }

    @Override
    public void listServers(String region) {
        System.out.println("Amazon: Listing servers in region " + region);
    }

    @Override
    public void getCDNAddress() {
        System.out.println("Amazon: Fetching CDN Address...");
    }

    @Override
    public void storeFile(String name) {
        System.out.println("Amazon: File '" + name + "' stored successfully.");
    }

    @Override
    public void getFile(String name) {
        System.out.println("Amazon: Retrieving file '" + name + "'.");
    }
}
