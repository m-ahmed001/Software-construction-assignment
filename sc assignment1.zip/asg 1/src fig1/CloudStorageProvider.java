public interface CloudStorageProvider {
    void storeFile(String name);
    void getFile(String name);
}
