public class Main {
    public static void main(String[] args) {

        System.out.println("--- Testing Amazon Cloud Services ---");
        Amazon amazon = new Amazon();
        amazon.createServer("Asia-Pacific");
        amazon.listServers("Asia-Pacific");
        amazon.storeFile("report.pdf");
        amazon.getFile("report.pdf");
        amazon.getCDNAddress();

        System.out.println("\n--- Testing Dropbox Cloud Storage ---");
        Dropbox dropbox = new Dropbox();
        dropbox.storeFile("photo.png");
        dropbox.getFile("photo.png");
    }
}
