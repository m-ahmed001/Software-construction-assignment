public class Dropbox implements CloudStorageProvider {

    @Override
    public void storeFile(String name) {
        System.out.println("Dropbox: File '" + name + "' uploaded.");
    }

    @Override
    public void getFile(String name) {
        System.out.println("Dropbox: File '" + name + "' downloaded.");
    }
}
