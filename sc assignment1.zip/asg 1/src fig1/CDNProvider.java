public interface CDNProvider {
    void getCDNAddress();
}
