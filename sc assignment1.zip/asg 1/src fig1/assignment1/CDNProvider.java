package assignment1;

public interface CDNProvider {
	 void getCDNAddress();

}
