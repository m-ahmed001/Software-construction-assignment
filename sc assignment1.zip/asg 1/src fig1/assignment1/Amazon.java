package assignment1;

public class Amazon implements CloudHostingProvider, CDNProvider, CloudStorageProvider {

    @Override
    public void storeFile(String name) {
        System.out.println("Amazon storing file: " + name);
    }

    @Override
    public void getFile(String name) {
        System.out.println("Amazon retrieving file: " + name);
    }

    @Override
    public void createServer(String region) {
        System.out.println("Amazon creating server in " + region);
    }

    @Override
    public void listServers(String region) {
        System.out.println("Amazon listing servers in " + region);
    }

    @Override
    public void getCDNAddress() {
        System.out.println("Amazon getting CDN address...");
    }
}

public class Dropbox implements CloudStorageProvider {

    @Override
    public void storeFile(String name) {
        System.out.println("Dropbox storing file: " + name);
    }

    @Override
    public void getFile(String name) {
        System.out.println("Dropbox retrieving file: " + name);
    }
}



