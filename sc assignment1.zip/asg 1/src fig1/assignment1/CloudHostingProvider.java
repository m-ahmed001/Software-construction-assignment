package assignment1;

public interface CloudHostingProvider {
	 void createServer(String region);
	    void listServers(String region);
}
