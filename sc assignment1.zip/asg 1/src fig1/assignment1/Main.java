package assignment1;

public class Main {
    public static void main(String[] args) {
        Amazon amazon = new Amazon();
        amazon.createServer("US-East");
        amazon.listServers("US-East");
        amazon.storeFile("Report.pdf");
        amazon.getFile("Report.pdf");
        amazon.getCDNAddress();

        Dropbox dropbox = new Dropbox();
        dropbox.storeFile("Notes.txt");
        dropbox.getFile("Notes.txt");
    }
	

}


