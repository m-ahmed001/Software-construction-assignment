package com.example.shipping;
import java.time.LocalDate;

public class Ground implements Shipping {
    @Override
    public double getCost(Order order) {
        if (order.getTotal() > 100) return 0;
        return Math.max(10, order.getTotalWeight() * 1.5);
    }

    @Override
    public LocalDate getDate(Order order) {
        return LocalDate.now().plusDays(5);
    }

}
