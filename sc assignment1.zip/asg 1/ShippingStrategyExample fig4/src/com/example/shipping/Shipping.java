package com.example.shipping;

public interface Shipping {

}
