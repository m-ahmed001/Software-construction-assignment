package com.example.shipping;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {
	private List<LineItem> lineItems = new ArrayList<>();
    private Shipping shipping;

    public void addItem(LineItem item) { lineItems.add(item); }
    public void setShippingType(Shipping shipping) { this.shipping = shipping; }

    public double getTotal() { return lineItems.stream().mapToDouble(LineItem::getPrice).sum(); }
    public double getTotalWeight() { return lineItems.stream().mapToDouble(LineItem::getWeight).sum(); }
    public double getShippingCost() { return shipping.getCost(this); }
    public LocalDate getShippingDate() { return shipping.getDate(this); }

    public void printSummary() {
        System.out.println("Order Summary:");
        for (LineItem item : lineItems) { System.out.println("  - " + item); }
        System.out.println("Total: $" + getTotal());
        System.out.println("Weight: " + getTotalWeight() + " kg");
        System.out.println("Shipping cost: $" + getShippingCost());
        System.out.println("Expected delivery: " + getShippingDate());
        System.out.println();
    }

}
