package com.example.shipping;

public class OrderDemo {

	public static void main(String[] args) {
		Order order1 = new Order();
        order1.addItem(new LineItem("Laptop", 90, 5));
        order1.addItem(new LineItem("Mouse", 15, 1));
        order1.setShippingType(new Ground());
        order1.printSummary();

        Order order2 = new Order();
        order2.addItem(new LineItem("Monitor", 200, 7));
        order2.setShippingType(new Air());
        order2.printSummary();
	}

}
