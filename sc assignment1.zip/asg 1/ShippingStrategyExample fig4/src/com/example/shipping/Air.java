package com.example.shipping;

import java.time.LocalDate;

public class Air  implements Shipping {
    @Override
    public double getCost(Order order) {
        return Math.max(20, order.getTotalWeight() * 3.0);
    }

    @Override
    public LocalDate getDate(Order order) {
        return LocalDate.now().plusDays(2);
    }
}
