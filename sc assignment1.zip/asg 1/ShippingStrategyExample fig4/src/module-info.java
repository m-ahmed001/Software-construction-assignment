/**
 * 
 */
/**
 * 
 */
module ShippingStrategyExample {
}