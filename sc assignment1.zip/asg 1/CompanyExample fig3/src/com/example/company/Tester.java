package com.example.company;

public class Tester  implements Employee {
    @Override
    public void doWork() {
        System.out.println("Tester is testing the software.");
    }

}
