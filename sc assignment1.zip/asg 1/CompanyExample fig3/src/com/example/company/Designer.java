package com.example.company;

public class Designer implements Employee {
    @Override
    public void doWork() {
        System.out.println("Designer is designing graphics.");
    }
	

}
