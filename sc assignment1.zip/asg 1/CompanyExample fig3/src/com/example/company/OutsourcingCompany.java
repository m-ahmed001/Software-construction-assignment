package com.example.company;
mport java.util.Arrays;
import java.util.List;

public class OutsourcingCompany extends Company {

    @Override
    List<Employee> getEmployees() {
        return Arrays.asList(
            new Programmer(),
            new Tester()
        );
    }
}
