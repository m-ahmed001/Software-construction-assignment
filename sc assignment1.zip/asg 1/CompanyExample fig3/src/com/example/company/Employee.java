package com.example.company;

public interface Employee {
	void doWork();
}
