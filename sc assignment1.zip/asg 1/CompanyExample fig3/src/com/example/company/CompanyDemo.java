package com.example.company;

public class CompanyDemo {

	public static void main(String[] args) {
		 Company gameDev = new GameDevCompany();
	        Company outsource = new OutsourcingCompany();

	        gameDev.createSoftware();
	        outsource.createSoftware();

	}

}
