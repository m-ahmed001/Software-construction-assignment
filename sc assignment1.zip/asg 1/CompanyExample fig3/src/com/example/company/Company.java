package com.example.company;
import java.util.List;

public abstract class Company {
	abstract List<Employee> getEmployees();

    // Template method
    public void createSoftware() {
        List<Employee> employees = getEmployees();
        System.out.println("\nCreating software with team:");
        for (Employee e : employees) {
            e.doWork();
        }
        System.out.println("Software development complete!\n");
    }

}
