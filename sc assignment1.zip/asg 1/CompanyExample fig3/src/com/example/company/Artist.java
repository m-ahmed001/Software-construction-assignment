package com.example.company;

public class Artist t implements Employee {
    @Override
    public void doWork() {
        System.out.println("Artist is creating art assets.");
    }
	

}
