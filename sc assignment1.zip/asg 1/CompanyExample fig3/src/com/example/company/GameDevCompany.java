package com.example.company;

import java.util.Arrays;
import java.util.List;

public abstract class GameDevCompany {

	public GameDevCompany() extends Company {

	    @Override
	    List<Employee> getEmployees() {
	        return Arrays.asList(
	            new Designer(),
	            new Artist()
	        );
	    }
		// TODO Auto-generated constructor stub
	}

}
