package transport;

public class Transport2 {
	 private Engine engine;
	    private Driver driver;

	    public Transport2(Engine engine, Driver driver) {
	        this.engine = engine;
	        this.driver = driver;
	    }

	    public void deliver(String destination, String cargo) {
	        System.out.println("Starting delivery of " + cargo + " to " + destination);
	        driver.navigate();
	        engine.move();
	        System.out.println("Delivery complete!\n");
	    }
}
