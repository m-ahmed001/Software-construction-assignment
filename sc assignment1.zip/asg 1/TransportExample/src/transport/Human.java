package transport;

public class Human  implements Driver {
    @Override
    public void navigate() {
        System.out.println("Human driver is navigating the route.");
    }

}
