package transport;

public class CombustionEngine mplements Engine {
    @Override
    public void move() {
        System.out.println("Combustion engine is moving using fuel.");
	

}
