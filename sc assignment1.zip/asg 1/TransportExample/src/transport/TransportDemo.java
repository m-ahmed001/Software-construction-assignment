package transport;

public class TransportDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Transport t1 = new Transport(new CombustionEngine(), new Human());
        t1.deliver("Karachi", "Furniture");

	}

}
