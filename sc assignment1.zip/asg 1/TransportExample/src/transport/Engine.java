package transport;

public interface Engine {
	 void move();
}
