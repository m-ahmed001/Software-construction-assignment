package transport;

public interface Driver {
	  void navigate();
}
